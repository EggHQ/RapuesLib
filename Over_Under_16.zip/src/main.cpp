/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\squid                                            */
/*    Created:      Mon Aug 28 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// MotorFR              motor         16              
// MotorBR              motor         17              
// MotorMR              motor         2               
// MotorFL              motor         6               
// MotorBL              motor         19              
// MotorML              motor         8               
// Puncher              motor         18              
// PuncherPos           rotation      11              
// Intake               motor         20              
// WingPiston           digital_out   H               
// InertialSensor       inertial      12              
// Hang                 digital_out   C               
// Blocker              digital_out   D               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

competition Competition;

double Auto;

int AutoCode = 0;
double AutoCodeTime[100];
double AutoCodeError[100];
double StartingPos;
double InitialTime;


double cmove;
double TrackingCircum = (10.21018 * 3)/5;
double totalmoved;

double chead;
double MotorValues;
double shead;
double constant = 3;
double smove;
double DirectionFix;
double TotalTurn = 0;
double LeftError;
double RightError;

double EncoderAverage = 0;

double TimeList[300];
double ManipulatedList[300];

//Stops all drivetrain motors
void MotorStop()
{
  MotorBL.spin(fwd,0,pct);
  MotorML.spin(fwd,0,pct);
  MotorFL.spin(fwd,0,pct);
  MotorBR.spin(fwd,0,pct);
  MotorMR.spin(fwd,0,pct);
  MotorFR.spin(fwd,0,pct);

  MotorBL.setBrake(hold);
  MotorML.setBrake(hold);
  MotorFL.setBrake(hold);
  MotorBR.setBrake(hold);
  MotorMR.setBrake(hold);
  MotorFR.setBrake(hold);
}


//Disables Motor Brakes
void MotorCoast()
{
  MotorBL.setBrake(coast);
  MotorML.setBrake(coast);
  MotorFL.setBrake(coast);
  MotorBR.setBrake(coast);
  MotorMR.setBrake(coast);
  MotorFR.setBrake(coast);
}

//values used in old movement function, a variable repurposed in second movement function
double a = -0.000240918; 
double c = 2.77397;

double InertiaAverage;

//Variables used in MoveForwards Function
double h;
double sPos = 0;
double robotVelocity;
double tuningValue = 7;

//Moves forwards designated amount of inches, with top speed of int speed, gradient MUST BE a even number, and the starting velocity will start the robot moving as if it is already that amount of inches through the program 
void MoveForwards(double inches, int speed, int gradient = 2, double StartingVelocity = 1,double ErrorAllowed = 0.05)
  {
    //resets motors to 0
    MotorFR.setPosition(0,rev);
    MotorMR.setPosition(0,rev);
    MotorBR.setPosition(0,rev);
    MotorFL.setPosition(0,rev);
    MotorML.setPosition(0,rev);
    MotorBL.setPosition(0,rev);

    if (inches < 0)
    {
      DirectionFix = -1;
    }
    else
    {
      DirectionFix = 1;
    }

    //inital calculations for formula based on input values
    inches = fabs(inches); //absolute value of inches (f for float, abs for absolute)
    inches += StartingVelocity; //horizontally shifts the target by the starting velocity
    a = (-1 *((pow(2,gradient) * speed)/(pow(inches,gradient)))); //finds a of vertex form
    h = (((inches)/2) - StartingVelocity); //finds h of vertex form
    EncoderAverage = 0;

    //debug
    //printf("A value: %f\n",a);
    //printf("H value: %f\n",h);

    while (EncoderAverage + StartingVelocity < inches - ErrorAllowed) //exit conditions can be tweeked with the ErrorAllowed
    {
      EncoderAverage = fabs((MotorFR.position(rev) + MotorMR.position(rev) + MotorBR.position(rev) + MotorFL.position(rev) + MotorML.position(rev) + MotorBL.position(rev)) * TrackingCircum / 6) + StartingVelocity;
      robotVelocity = a * (pow(EncoderAverage - h,gradient)) + speed; //calculates robot velocity based on a and h
      robotVelocity *= DirectionFix;
        //spins all the motors selected velocity
        MotorBL.spin(fwd,robotVelocity,pct);
        MotorML.spin(fwd,robotVelocity,pct);
        MotorFL.spin(fwd,robotVelocity,pct);
        MotorBR.spin(fwd,robotVelocity,pct);
        MotorMR.spin(fwd,robotVelocity,pct);
        MotorFR.spin(fwd,robotVelocity,pct);
    }
    MotorStop();
  }

//Old Moveforwards functon Will delete later
void MoveForwards2(double inches, bool forwards,int speed)
  {
    constant = 3;
    MotorFR.setPosition(0,rev);
    EncoderAverage = MotorFR.position(rev);
    
    smove = EncoderAverage * TrackingCircum;
    printf("smove: %f\n",smove);
    printf("DirectionFix this%f\n",DirectionFix);
    DirectionFix = 1;
    MotorValues = 50;
    LeftError = 0;
    RightError = 0;
    printf("DirectionFix now%f\n",DirectionFix);
    if (forwards == true)
      {
        DirectionFix = 1;
      }
        else
          {
            DirectionFix = -1;
          } 
    printf("DirectionFix then%f\n",DirectionFix);  
    printf("detaMove: %f\n",(smove - (EncoderAverage * TrackingCircum)));
    if (inches > (smove - (EncoderAverage * TrackingCircum)))
    {
      printf("clause 1 TRUE\n");
    }
    else
    {
      printf("clause 1 FALSE\n");
    }
    if ((MotorValues > (constant+0.3)))
    {
      printf("clause 2 TRUE\n");
    }
    else
    {
      printf("clause 2 FALSE\n");
    }
    if ((inches > (smove - (EncoderAverage * TrackingCircum))  ) and (MotorValues > (constant+0.3)) )
    {
      printf("AND is TRUE\n");
    }
    else
    {
      printf("AND is FALSE\n");
    }

    printf("MotorValues: %f\n",MotorValues);
    while((inches > (smove - (EncoderAverage * TrackingCircum))  ) and ((MotorValues > (constant+0.3))) )
      {
        printf("It gets here\n");
        EncoderAverage = MotorFR.position(rev);

        MotorValues = ( speed * ( 1 - ( ((EncoderAverage*TrackingCircum * DirectionFix) - smove ) / (inches) ) ) ) ;
        MotorValues = (a*pow(MotorValues,3.0) + c * MotorValues) + (constant * DirectionFix);

        MotorValues = MotorValues * DirectionFix;
        MotorBL.spin(fwd,MotorValues,pct);
        MotorML.spin(fwd,MotorValues,pct);
        MotorFL.spin(fwd,MotorValues,pct);
        MotorBR.spin(fwd,MotorValues,pct);
        MotorMR.spin(fwd,MotorValues,pct);
        MotorFR.spin(fwd,MotorValues,pct);
        MotorValues = fabs(MotorValues);
    printf("MotorValues: %f\n",MotorValues);
    //printf("Constant: %f\n",constant);
    if (inches > (smove - (EncoderAverage * TrackingCircum)))
    {
      printf("clause 1 TRUE\n");
    }
    else
    {
      printf("clause 1 FALSE\n");
    }
    if ((MotorValues > (constant+0.3) * DirectionFix * -1))
    {
      printf("clause 2 TRUE\n");
    }
    else
    {
      printf("clause 2 FALSE\n");
    }
    if ((inches > (smove - (EncoderAverage * TrackingCircum))  ) and (MotorValues > (constant+0.3)) )
    {
      printf("AND is TRUE\n");
    }
    else
    {
      printf("AND is FALSE\n");
    }
      }
      MotorStop(); 
  }

//variables for Turn function
bool left2;
int leftModifier;
bool exitCondition = true;
double NotSoTotalTurn = 0;

//Turns specifyed amount of degrees
void Turn(int TurnValue,int speed)
  {
    wait(5,msec);
    left2 = true;
    DirectionFix = 1;
    exitCondition = true;
    if (TurnValue < 0)
    {
      DirectionFix = -1;
      left2 = false;
    }
    TotalTurn = TotalTurn + TurnValue;
    MotorValues = 4;
    NotSoTotalTurn = TotalTurn;
    wait(5,msec);
    if (NotSoTotalTurn < 0)
    {
      NotSoTotalTurn = fabs(NotSoTotalTurn);
    }
    //debug info about inputs in function
    printf("\n\n\n------------------------------\n\nint TurnValue = %d\n",TurnValue);
    printf("int speed = %d\n",speed); 
    printf("int DirectionFix = %f\n",DirectionFix);
    printf("int TotalTurn = %f\n",TotalTurn);
    printf("int NotSoTotalTurn = %f\n",NotSoTotalTurn);
    printf("double InertiaSensor = %f\n",InertialSensor.rotation(deg));
    printf("\n\n------------------------------\n\n");

    for(int i = 0; i < 5;i++)
      {
        while( exitCondition ) 
          {
            MotorValues = speed * ( 1 - fabs( ( fabs(InertialSensor.rotation(deg)) - (NotSoTotalTurn-TurnValue) ) / (TurnValue) ) ) ;
            wait(10,msec);
            MotorValues = fabs(MotorValues);
            MotorValues += 3;
            exitCondition = TotalTurn + (0.25 * DirectionFix) < InertialSensor.rotation(deg); //< //NEGATIVE
            if(left2)
              {
                exitCondition = TotalTurn + (0.25 * DirectionFix) > InertialSensor.rotation(deg); //> //POSITIVE
                MotorBL.spin(fwd,MotorValues,pct);
                MotorML.spin(fwd,MotorValues,pct);
                MotorFL.spin(fwd,MotorValues,pct);
                MotorBR.spin(fwd,MotorValues*-1,pct);
                MotorMR.spin(fwd,MotorValues*-1,pct);
                MotorFR.spin(fwd,MotorValues*-1,pct);
              }
            else
              {
                MotorBL.spin(reverse,MotorValues,pct);
                MotorML.spin(reverse,MotorValues,pct);
                MotorFL.spin(reverse,MotorValues,pct);
                MotorBR.spin(reverse,MotorValues*-1,pct);
                MotorMR.spin(reverse,MotorValues*-1,pct);
                MotorFR.spin(reverse,MotorValues*-1,pct);
              }
          }
          MotorStop();
          wait(0.1,sec);
      }
  }


//Driver control Drivetrain
void Driving() //Driver control, puts onto a cubic function
  {
    double joystickL = ((0.0000530602 * pow(Controller1.Axis3.position(),3.0)) + 0.469292*Controller1.Axis3.position()) + ( (0.000025392 * pow(Controller1.Axis1.position(),3.0)) + (0.745584 * Controller1.Axis1.position()) );
    double joystickR = ((0.0000530602 * pow(Controller1.Axis3.position(),3.0)) + 0.469292*Controller1.Axis3.position()) - ( (0.000025392 * pow(Controller1.Axis1.position(),3.0) + (0.745584 * Controller1.Axis1.position())) );
    
    //moves all the motors forwards
    MotorFR.spin(fwd,joystickR, pct);
    MotorFL.spin(fwd,joystickL, pct);
    MotorMR.spin(fwd,joystickR, pct);
    MotorML.spin(fwd,joystickL, pct);
    MotorBR.spin(fwd,joystickR, pct);
    MotorBL.spin(fwd,joystickL, pct);
  }

void Punch()
{
  Puncher.spin(reverse,95,pct);
  wait(0.5,sec);
  waitUntil(PuncherPos.position(deg) >= 62);
  Puncher.spin(fwd,0,pct);
}

//variables for 'toggle punch mode'
double cooldown = 0;
bool punch = false;

//Driver control Puncher code
void PuncherCode()
{
  //code for 'toggle punch mode' will punch forever until toggled
  if (Controller1.ButtonDown.pressing()) {
    if (punch == false) {
      Puncher.spin(reverse,95,pct);
      if (cooldown + 0.5 < Brain.timer(sec))
        {
          punch = true;
          cooldown = Brain.timer(sec);
        }
      
    }
    else {
        if (cooldown + 0.5 < Brain.timer(sec))
        {
          punch = false;
          cooldown = Brain.timer(sec);
        }
    }
}
  //Normal Punch code, enabled when it is not in 'toggle punch mode'
  else if (Controller1.ButtonR2.pressing() and !punch)
  {
    Puncher.setBrake(coast);
    Puncher.spin(reverse,95,pct);
  }
  else if (PuncherPos.position(deg) >= 60 and !punch)
  {
    Puncher.spin(fwd,0,pct);
    Puncher.setBrake(coast);
  }
  else if (!punch)
  {
    Puncher.spin(reverse,95,pct);
  }
}

//Driver control Spins intake
void IntakeCode()
{
  if (Controller1.ButtonL1.pressing())
  {
    Intake.spin(fwd,100,pct);
  }
  else if (Controller1.ButtonL2.pressing())
  {
    Intake.spin(fwd,-100,pct);
  }
  else
  {
    Intake.spin(fwd,0,pct);
  }
}

//Wing toggle variables
bool wing = false;

//Driver control Wing deploy code
void WingCode()
{
  if (Controller1.ButtonR1.pressing())
  {
    if (wing == false)
    {
      WingPiston.set(true);
      if (cooldown + 0.5 < Brain.timer(sec))
        {
          wing = true;
          cooldown = Brain.timer(sec);
        }
    }
    else 
    {
      WingPiston.set(false);
      if (cooldown + 0.5 < Brain.timer(sec))
      {
        wing = false;
        cooldown = Brain.timer(sec);
      }
    }
  } 
}

void HangCode() 
{
  if (Controller1.ButtonY.pressing()) {
    Hang.set(true);
  }
}

//blocker toggle variables
bool blocker = false;

//blocker Driver control code
void BlockerCode()
{
 if (Controller1.ButtonX.pressing()) {
    if (blocker == false) 
    {
      Blocker.set(true);
      if (cooldown + 0.5 < Brain.timer(sec))
      {
        blocker = true;
        cooldown = Brain.timer(sec);
      }
    }
    else
    {
      Blocker.set(false);
      if (cooldown + 0.5 < Brain.timer(sec))
      {
        blocker = false;
        cooldown = Brain.timer(sec);
      }
    }
  } 
}
//preAuto stuff
void AutoSelection(int Mod)
  {
      Brain.Screen.drawImageFromFile("AutoSelector2.png",0,0); 
      wait(0.5,sec);
      waitUntil(Brain.Screen.pressing());

      if(Brain.Screen.xPosition() > 240)
        {
          if(Brain.Screen.yPosition() > 136)
            {
              Auto = 4 + Mod;
            }
            else
              {
                Auto = 2 + Mod;
              }
        }
          else
            {
              if(Brain.Screen.yPosition() > 136)
                {
                  Auto = 3 + Mod;
                }
                  else
                    {
                      Auto = 1 + Mod;
                    }
            }

  }

bool Skills;

void pre_auton(void) {
  // Initializing Robot Configuration
  vexcodeInit();
  Controller1.Screen.clearScreen();
  Controller1.Screen.print("PreAuto");
  PuncherPos.resetPosition();
  MotorFR.setPosition(0,rev);
  MotorMR.setPosition(0,rev);
  MotorBR.setPosition(0,rev);
  MotorFL.setPosition(0,rev);
  MotorML.setPosition(0,rev);
  MotorBL.setPosition(0,rev);


  InertialSensor.calibrate();
  Brain.Screen.printAt(50, 50, false, "Calibrating..."); //Calibrates the Inertia sensor so heading is accurate
  waitUntil(!InertialSensor.isCalibrating());
  Brain.Screen.printAt(50, 50, false, "Not Calibrating");

  Brain.Screen.drawImageFromFile("MatchTypeSelector2.png",0,0); //starts the GUI that sets up the right Autonomous for matches or skills
  waitUntil(Brain.Screen.pressing());
  Brain.Screen.clearScreen();
  if(Brain.Screen.xPosition() > 240 ) //detects what side of the screen got pushed
    {
      Skills = false;
      Brain.Screen.drawImageFromFile("TeamSelector.png", 0, 0); //select either blue or red side for matches
      wait(0.5,sec);
      waitUntil(Brain.Screen.pressing());
      Brain.Screen.clearScreen();
        if(Brain.Screen.xPosition() > 240 )
          {
            AutoSelection(0);
            Brain.Screen.clearScreen();
            Brain.Screen.drawImageFromFile("VEXbrainScreen.png",0,0); //logo for Red side
            //Brain.Screen.drawImageFromFile("RedFox2.png",380,172); 
            Controller1.Screen.setCursor(0, 0);
            Controller1.Screen.print("Auto %f",Auto); //prints the auto on controller to make sure the right one was selected
          }
            else
              {
                AutoSelection(4);
                Brain.Screen.clearScreen();
                Brain.Screen.drawImageFromFile("VEXbrainScreen.png",380,172); 
                //Brain.Screen.drawImageFromFile("FerociousFoxLogoBlue.png",0,0); //logo for Blue side
                Controller1.Screen.setCursor(0, 0);
                Controller1.Screen.print("Auto %f",Auto);
                if (Auto == 8)
                  {
                    while(true)
                      {
                        Brain.Screen.clearScreen();
                        Brain.Screen.drawImageFromFile("Youareanidiot1.png",58,0); //Brain demonstation video
                        wait(0.05,sec);
                        Brain.Screen.setFillColor(white);
                        Brain.Screen.drawRectangle(0, 0, 480, 272);
                        Brain.Screen.drawImageFromFile("idiot2.png", 57, 0);
                        wait(0.05,sec);
                      }

                  }
              }

    }
      else
        {
          Skills = true;
          Brain.Screen.clearScreen();
      Brain.Screen.drawImageFromFile("SkillsSelector.png",0,0); //auto selector for skills
      wait(0.5,sec);
      waitUntil(Brain.Screen.pressing());

      if(Brain.Screen.xPosition() > 240)
        {
          if(Brain.Screen.yPosition() > 136)
            {
              Auto = 4;
            }
            else
              {
                Auto = 2;
                  Controller1.Screen.setCursor(0, 0);
                  Controller1.Screen.print("Auto %f",Auto);
              }
        }
          else
            {
              if(Brain.Screen.yPosition() > 136)
                {
                  Auto = 3;
                }
                  else
                    {
                      Auto = 1;
                    }
            }
            Controller1.Screen.setCursor(0, 0);
            Controller1.Screen.print("Auto %f",Auto);
            Brain.Screen.clearScreen();
            Brain.Screen.drawImageFromFile("BlueShark2.png",480,172);
            Brain.Screen.drawImageFromFile("FerociousFoxLogoBlue.png",0,0); 
        }
  
while(true)
  {
    wait(1,sec); //does nothing until it exits preauto
  }
}



//comp template
void usercontrol(void)
{
  Controller1.Screen.clearScreen();
  Controller1.Screen.print("User Control");
  Hang.set(false);

  while(true)
  {
    Driving();
    WingCode();
    IntakeCode();
    PuncherCode();
    HangCode();
    BlockerCode();
    wait(1,msec); //necessary for the brain to not explode and die from lag
  }

}

void autonomous(void)
{ 
  TotalTurn = 0; //sets current target to 0 deg
  /* when testing allows for executing autonomous without navigating through the ui */
  //Skills = true;
  //Auto = 1;

if(Skills)
  {
    if (Auto == 1) //skills prog autonomous
    {
      MoveForwards(15,true,10); //moves out of starting zone
      Turn(67, 35); //turns into match load bar
      wait(0.5,sec);
      for(int i = 0; i <49; i++) //shoots 48 times
      {
        Punch();
      }

      Turn(-70,35); //Riley add comments please
      MoveForwards(16,false,10);//
      Turn(50,25);//
      MoveForwards(80.5,false,99);//

    
      Turn(90, 45);
      MoveForwards(22, false, 50);
      Turn(90, 45);
      MoveForwards(24, false, 60);
      Turn(-90,45);
      MoveForwards(22, false, 40);
      Turn(-90, 45);
      
      WingPiston.set(true);
      MoveForwards(28, false, 99);
      WingPiston.set(false);
      MoveForwards(28, true, 70);
      Turn(-90, 45);
      MoveForwards(10, true, 39);
      Turn(90, 45);
      WingPiston.set(true);
      MoveForwards(28, false, 99);
      WingPiston.set(false);
      MoveForwards(28, true, 70);
      Turn(-90, 45);
      Intake.spin(fwd, 100, pct);
      MoveForwards(36, true, 70);
      Turn(54, 25);
      WingPiston.set(true);
      MoveForwards(50, false, 90);
        }
  }
else //non skills ---
{
  if (Auto == 1)
  {
    //Match load side auto (Winpoint)
    MoveForwards2(4.5, 16);
    
    WingPiston.set(true);
    wait(0.25,sec);
    Turn(-160, 70);
    WingPiston.set(false);
    
    MoveForwards2(-13, 55);
    Turn(-155, 65);
    Intake.spin(fwd, 80, pct);
    wait(0.5, sec);
    Intake.spin(fwd, 0, pct);
    Turn(180, 75);
    MoveForwards2(-13, 65);
    MoveForwards2(4, 60);
    Turn(-45, 35); 
    MoveForwards2(36, 70);
    Turn(-45, 35); 
    MoveForwards2(28.5, 70);
  
  }

  if(Auto == 2)
  {
    //goal side code (4 tribals scored)
    MoveForwards(8,false,40);
    WingPiston.set(true);
    MoveForwards(9.5, true, 15);
    Turn(-60,45);
    WingPiston.set(false);
    Turn(85, 35);
    MoveForwards(30,false,60);
    MoveForwards(2, true, 2);
    Turn(-20,10);
    MoveForwards(35, true, 50);
    Turn(-47, 20);
    MoveForwards(26, true, 30);
    Intake.spin(fwd,100,pct);
    wait(0.5, sec);
    Intake.spin(fwd,0,pct);
  }
  if(Auto == 3)
  {
    //distractor auto (winpoint side)
    MoveForwards2(-43.5, 70);
    Turn(90, 45);
    WingPiston.set(true);
    MoveForwards2(-36,70);
    WingPiston.set(false);

  }
}
}

int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
