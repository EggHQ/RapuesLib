using namespace vex;

extern brain Brain;

// VEXcode devices
extern controller Controller1;
extern motor MotorFR;
extern motor MotorBR;
extern motor MotorMR;
extern motor MotorFL;
extern motor MotorBL;
extern motor MotorML;
extern motor Puncher;
extern rotation PuncherPos;
extern motor Intake;
extern digital_out WingPiston;
extern inertial InertialSensor;
extern digital_out Hang;
extern digital_out Blocker;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );